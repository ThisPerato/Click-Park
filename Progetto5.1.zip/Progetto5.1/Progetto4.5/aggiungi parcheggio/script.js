function checkKeywords(input){
    var keywords = ["Piazza", "Via", "Largo", "Viale"];

    for (var i=0; i<keywords.length; i++){
        if (input.includes(keywords[i])){
            return true;
        }
    }
    return false;
}

function validateForm(){
    var viaInput= document.getElementById("via");
    var inputValue= viaInput.value;
    var containsKeyword=checkKeywords(inputValue);
    if (!containsKeyword){
        alert("Inserisci una destinazione corretta!");
        return false;
    }
}